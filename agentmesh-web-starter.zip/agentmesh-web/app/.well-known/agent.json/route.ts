import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const origin = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
  return NextResponse.json({
    schema: "https://agentmesh.dev/schemas/agent-profile.v1.json",
    id: `${origin}/#agentmesh`,
    name: "AgentMesh Web",
    version: "1.0.0",
    description: "An open, inspectable directory where humans and external agents discover community repair and service providers.",
    website: origin,
    protocols: ["HTTP+JSON", "A2A-AgentCard-1.0-compatible-discovery-profile"],
    discovery: {
      agentProfile: `${origin}/.well-known/agent.json`,
      a2aAgentCard: `${origin}/.well-known/agent-card.json`,
      llms: `${origin}/llms.txt`
    },
    endpoints: {
      execute: { url: `${origin}/api/agent/execute`, method: "POST", contentType: "application/json" }
    },
    capabilities: [
      { id: "list_services", description: "Search the public service directory.", inputSchema: { type: "object", properties: { query: { type: "string", maxLength: 100 } }, required: ["query"], additionalProperties: false }, sideEffects: false },
      { id: "request_quote", description: "Stage a quote request for a listed provider. Demo-only; no external message is sent.", inputSchema: { type: "object", properties: { serviceId: { type: "string" }, description: { type: "string", maxLength: 500 } }, required: ["serviceId", "description"], additionalProperties: false }, sideEffects: "creates-ephemeral-demo-record", requiresHumanConfirmation: true }
    ],
    trust: {
      transport: "HTTPS required in production",
      manifestIntegrity: "Unsigned public metadata; verify HTTPS and deployment ownership independently.",
      authorization: "Capability allowlist; no arbitrary URL fetch, shell, payment, or account access.",
      dataHandling: "Demo quote requests are ephemeral in-memory records and may be lost on restart."
    },
    rateLimits: { perIpPerMinute: 30, note: "Illustrative policy; add shared storage/rate limiting before production." },
    contact: { documentation: `${origin}/llms.txt` }
  }, { headers: { "Cache-Control": "public, max-age=300" } });
}
