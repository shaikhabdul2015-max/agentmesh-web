import { NextResponse } from "next/server";

export async function GET() {
  const origin = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
  return NextResponse.json({
    protocolVersion: "1.0.0",
    name: "AgentMesh Web",
    description: "Discover community service providers and stage human-approved demo quote requests.",
    version: "1.0.0",
    supportedInterfaces: [{
      url: `${origin}/api/agent/execute`,
      protocolBinding: "HTTP+JSON",
      protocolVersion: "1.0.0"
    }],
    provider: { organization: "AgentMesh Web Open Source Demo", url: origin },
    documentationUrl: `${origin}/llms.txt`,
    capabilities: { streaming: false, pushNotifications: false, stateTransitionHistory: false },
    defaultInputModes: ["application/json"],
    defaultOutputModes: ["application/json"],
    skills: [
      { id: "list_services", name: "Search services", description: "Find matching service providers.", tags: ["discovery", "search"], examples: ["Find bicycle repair"] },
      { id: "request_quote", name: "Stage quote request", description: "Create an ephemeral quote request after explicit human confirmation.", tags: ["service", "quote"], examples: ["Request an indicative quote"] }
    ],
    securitySchemes: {},
    security: []
  }, { headers: { "Cache-Control": "public, max-age=300" } });
}
