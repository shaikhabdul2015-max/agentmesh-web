import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { randomUUID } from "crypto";

const services = [
  { id: "svc-cycle-01", name: "CycleFix Collective", category: "bicycle repair", description: "Community-run bicycle repair, tune-ups and safety checks.", area: "Brooklyn", indicativePrice: "From $20" },
  { id: "svc-device-02", name: "Reboot Repair Lab", category: "device repair", description: "Independent laptop and phone diagnostics with transparent estimates.", area: "Manhattan", indicativePrice: "Estimate first" },
  { id: "svc-home-03", name: "GoodHands Home Care", category: "home services", description: "Small home repairs, furniture assembly and accessibility fixes.", area: "Queens", indicativePrice: "From $35" }
];

// Ephemeral demonstration storage only. Replace with a database and retention policy for production.
const quoteRequests: Array<{ requestId: string; serviceId: string; description: string; createdAt: string }> = [];

const base = z.object({
  protocol: z.literal("agentmesh.v1"),
  action: z.enum(["list_services", "request_quote"]),
  input: z.record(z.unknown()),
  context: z.object({
    purpose: z.string().max(100).optional(),
    requestedBy: z.string().max(100).optional(),
    humanConfirmed: z.boolean().optional()
  }).optional()
}).strict();

const listInput = z.object({ query: z.string().trim().min(1).max(100) }).strict();
const quoteInput = z.object({
  serviceId: z.string().min(1).max(80),
  description: z.string().trim().min(5).max(500)
}).strict();

function jsonError(message: string, requestId: string, status: number) {
  return NextResponse.json({ ok: false, error: message, meta: { requestId } }, { status });
}

export async function POST(req: NextRequest) {
  const requestId = randomUUID();
  if (!req.headers.get("content-type")?.includes("application/json")) {
    return jsonError("Content-Type must be application/json.", requestId, 415);
  }
  let raw: unknown;
  try { raw = await req.json(); } catch { return jsonError("Malformed JSON body.", requestId, 400); }

  const parsed = base.safeParse(raw);
  if (!parsed.success) return jsonError("Invalid request schema or unsupported action.", requestId, 400);

  const { action, input, context } = parsed.data;
  if (action === "list_services") {
    const validated = listInput.safeParse(input);
    if (!validated.success) return jsonError("Invalid list_services input.", requestId, 400);
    const q = validated.data.query.toLowerCase();
    const items = services.filter(s => `${s.name} ${s.category} ${s.description} ${s.area}`.toLowerCase().includes(q));
    return NextResponse.json({
      ok: true, data: { items, count: items.length },
      meta: { requestId, policy: "ALLOW_READ_ONLY", protocol: "agentmesh.v1" }
    });
  }

  const validated = quoteInput.safeParse(input);
  if (!validated.success) return jsonError("Invalid request_quote input.", requestId, 400);
  if (context?.humanConfirmed !== true) return jsonError("request_quote requires context.humanConfirmed=true.", requestId, 403);
  if (!services.some(s => s.id === validated.data.serviceId)) return jsonError("Unknown serviceId.", requestId, 404);

  const request = {
    requestId: `quote_${randomUUID()}`,
    serviceId: validated.data.serviceId,
    description: validated.data.description,
    createdAt: new Date().toISOString()
  };
  quoteRequests.push(request);
  return NextResponse.json({
    ok: true,
    data: { requestId: request.requestId, status: "staged_demo_only", externalContacted: false, paymentTaken: false },
    meta: { requestId, policy: "ALLOW_WITH_HUMAN_CONFIRMATION", protocol: "agentmesh.v1" }
  }, { status: 201 });
}
